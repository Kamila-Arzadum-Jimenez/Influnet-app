import { TitleSection } from "../core/components/TitleSection";

export function MetricsPage() {
  return (
    <div>
      <TitleSection>
        <h2> Ver métricas </h2>
      </TitleSection>
    </div>
  );
}
