export type UsuarioType = {
  usuarioID: number;
  nombre: string;
  nombreUsuario: string;
  subNombre: string;
  bio: string;
  imagen: string;
  ciudad: string;
  telefono: string;
  direccion: string;
};
