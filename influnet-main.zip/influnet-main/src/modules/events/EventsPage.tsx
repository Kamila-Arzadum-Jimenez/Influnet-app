import { TitleSection } from "../core/components/TitleSection";

export function EventsPage() {
  return (
    <div>
      <TitleSection>
        <h2> Vehículos </h2>
      </TitleSection>
    </div>
  );
}
